document.addEventListener('DOMContentLoaded', () => {
    // Smooth scrolling for nav links
    const navLinks = document.querySelectorAll('nav a');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            targetSection.scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Buy Script Functionality
    const buyScriptButtons = document.querySelectorAll('.buy-script');
    
    buyScriptButtons.forEach(button => {
        button.addEventListener('click', () => {
            const scriptName = button.getAttribute('data-script');

            Swal.fire({
                title: 'Compra Script Cronus Zen',
                html: `
                    <div style="background: linear-gradient(135deg, #1a1a3a 0%, #0a0a1a 100%); padding: 20px; border-radius: 15px;">
                        <h2 style="color: #7ed957;">Compra Script Cronus Zen</h2>
                        <p style="color: #e0e0ff;">Precio: 35€</p>
                        <form id="payment-form">
                            <h3 style="color: #7ed957;">Pago con Tarjeta de Crédito/Débito</h3>
                            <input type="text" placeholder="Nombre completo" required class="swal2-input" style="margin-bottom: 10px;">
                            <input type="text" placeholder="Número de tarjeta" pattern="[0-9]{16}" required class="swal2-input" style="margin-bottom: 10px;">
                            <div style="display: flex; justify-content: space-between;">
                                <input type="text" placeholder="MM/AA" pattern="(0[1-9]|1[0-2])\/[0-9]{2}" required class="swal2-input" style="width: 45%;">
                                <input type="text" placeholder="CVV" pattern="[0-9]{3}" required class="swal2-input" style="width: 45%;">
                            </div>
                        </form>
                    </div>
                `,
                background: 'transparent',
                showCancelButton: false,
                confirmButtonText: 'Pagar',
                confirmButtonColor: '#7ed957',
                preConfirm: () => {
                    const paymentForm = document.getElementById('payment-form');
                    if (paymentForm.checkValidity()) {
                        Swal.fire({
                            icon: 'success',
                            title: '¡Compra Exitosa!',
                            text: `Has comprado el script de ${scriptName}. El script será enviado a tu correo.`,
                            background: 'linear-gradient(135deg, #1a1a3a 0%, #0a0a1a 100%)',
                            color: '#e0e0ff'
                        });
                        return true;
                    }
                    Swal.showValidationMessage('Por favor complete todos los campos correctamente');
                    return false;
                },
                didRender: () => {
                    const paymentForm = document.getElementById('payment-form');
                    paymentForm.addEventListener('submit', (e) => {
                        e.preventDefault();
                    });
                }
            });
        });
    });
});